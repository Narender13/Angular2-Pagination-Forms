"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var login_service_1 = require("../service/login.service");
var LoginComponent = (function () {
    function LoginComponent(route, _user) {
        this.route = route;
        this._user = _user;
        this.rememberme = this.getRememberMe().rememberme;
        console.log(typeof this.rememberme);
        if (this.rememberme == 'true') {
            this.user = this.getRememberMe().user;
        }
    }
    ;
    LoginComponent.prototype.submitLogin = function (form, valid) {
        this.submitted = true;
        this.loading = true;
        if (valid && form.username === 'joe@abc.com' && form.password === 'abcd@123') {
            this._user.setUserLoggedIn();
            this.errorLogin = false;
            this.route.navigate(['/home']);
            this.loading = false;
            this.setRememberMe(form, this.rememberme);
        }
        else {
            this.errorLogin = true;
            this.loading = false;
        }
    };
    LoginComponent.prototype.setRememberMe = function (form, rememberme) {
        localStorage.setItem('rememberMe', rememberme);
        localStorage.setItem('username', form.username);
    };
    LoginComponent.prototype.getRememberMe = function () {
        return {
            'rememberme': localStorage.getItem('rememberMe') || false,
            'user': localStorage.getItem('username') || null,
        };
    };
    LoginComponent.prototype.ngOnInit = function () {
    };
    return LoginComponent;
}());
LoginComponent = __decorate([
    core_1.Component({
        selector: 'loginForm',
        templateUrl: "./login.html"
    }),
    __metadata("design:paramtypes", [router_1.Router, login_service_1.UserService])
], LoginComponent);
exports.LoginComponent = LoginComponent;
//# sourceMappingURL=login.component.js.map