import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Router } from '@angular/router'
import { NgForm } from '@angular/forms';
import { UserService } from '../service/login.service'


@Component({
    selector: 'loginForm',
    templateUrl: `./login.html`
})
export class LoginComponent implements OnInit {
    public errorLogin: boolean;
     rememberme: any;
    submitted: boolean;
    private loading: boolean;
    user: string;

    constructor(private route: Router, private _user: UserService) {

        this.rememberme = this.getRememberMe().rememberme;
        console.log(typeof this.rememberme);
         if (this.rememberme == 'true') {
            this.user = this.getRememberMe().user;

        }

    };
    submitLogin(form: any, valid: boolean): void {
        this.submitted = true;
        this.loading = true;
        if (valid && form.username === 'joe@abc.com' && form.password === 'abcd@123') {
            this._user.setUserLoggedIn();
            this.errorLogin = false;
            this.route.navigate(['/home']);
            this.loading = false;
            this.setRememberMe(form, this.rememberme);

        } else {
            this.errorLogin = true;
            this.loading = false;
        }
    }
    setRememberMe(form: any, rememberme: any) {
        localStorage.setItem('rememberMe', rememberme);
        localStorage.setItem('username', form.username);
    }
    getRememberMe() {
        return {
            'rememberme': localStorage.getItem('rememberMe') || false ,
            'user': localStorage.getItem('username') || null,
        };
    }
    ngOnInit() {



    }
}
