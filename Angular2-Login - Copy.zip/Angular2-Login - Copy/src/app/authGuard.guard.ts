import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/observable';
import { UserService } from './service/login.service';



@Injectable()
export class AuthguardGuard implements CanActivate {

    constructor(private router: Router, private _user: UserService) { }

    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> {
        if (this._user.getUserLoggedIn() ) {
        return this._user.getUserLoggedIn();
    } else {
        this.router.navigate(['/login']);
    }

    }

}

  
