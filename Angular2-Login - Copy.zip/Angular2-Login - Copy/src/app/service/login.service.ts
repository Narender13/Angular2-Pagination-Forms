import { Injectable } from '@angular/core';

@Injectable()

export class UserService {
    private IsUserLoggedIn: any;
    private username: any;

    constructor() {
        this.IsUserLoggedIn = false;
    }

    setUserLoggedIn() {
        this.IsUserLoggedIn = true;

    }
    getUserLoggedIn() {
        return this.IsUserLoggedIn;

    }
};