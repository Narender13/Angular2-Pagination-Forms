import { Component, OnInit, OnChanges, Input, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from './service/login.service';
import { MessageService } from './service/message.service';
import { AuthguardGuard } from './authGuard.guard';
import {
    Router,
    // import as RouterEvent to avoid confusion with the DOM Event
    Event as RouterEvent,
    NavigationStart,
    NavigationEnd,
    NavigationCancel,
    NavigationError
} from '@angular/router';

@Component({
  selector: 'my-app',
  templateUrl: `app/app.component.html`,
})
export class AppComponent implements OnInit {
  public loginDetail: boolean;
  message: any;
   loading: boolean = true;
   isbindingDone: any;

  constructor(private messageService: MessageService,
    private route: ActivatedRoute,
    private router: Router, private user: UserService, private _uthguardGuard: AuthguardGuard) {
    this.messageService.getMessage().subscribe(message => { this.message = message; });
     router.events.subscribe((event: RouterEvent) => {
            this.navigationInterceptor(event);
        });
}
 navigationInterceptor(event: RouterEvent): void {
        if (event instanceof NavigationStart) {
            this.loading = true;
        }
        if (event instanceof NavigationEnd) {

            setTimeout(() => this.loading = false, 1000);
        }

        // Set loading state to false in both of the below events to hide the spinner in case a request fails
        if (event instanceof NavigationCancel) {
            setTimeout(() => this.loading = false, 1000);
        }
        if (event instanceof NavigationError) {
            setTimeout(() => this.loading = false, 1000);
        }
    }
  logout() {
    this.messageService.sendMessage('false');
    this.router.navigate(['/login']);
}
  ngOnInit() {
 this.loading = false;
 this.messageService.getLoadingMessage().subscribe(loading => { this.isbindingDone = loading; });
  }


}
