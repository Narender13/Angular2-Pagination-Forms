"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var forms_1 = require("@angular/forms");
var router_1 = require("@angular/router");
var FormComponent = (function () {
    function FormComponent(_formBuilder, route) {
        this._formBuilder = _formBuilder;
        this.route = route;
        this.events = []; // use later to display form changes
    }
    ;
    FormComponent.prototype.ngOnInit = function () {
        // we will initialize our form model here
        // the short way
        this.registerForm = this._formBuilder.group({
            firstname: ['', forms_1.Validators.required],
            lastname: ['', forms_1.Validators.required],
            address: this._formBuilder.group({
                street: ['', forms_1.Validators.required],
                zip: ['', forms_1.Validators.required],
                city: ['', forms_1.Validators.required]
            })
        });
        this.myForm = this._formBuilder.group({
            name: ['', [forms_1.Validators.required]],
            addresses: this._formBuilder.array([
                this.initAddress(),
            ])
        });
        this.user = {
            name: '',
            address: {
                street: '',
                postcode: ''
            }
        };
    };
    FormComponent.prototype.initAddress = function () {
        var phoneNoRegex = /^\d{3}-?\d{3}-?\d{4}$/g;
        // initialize our address
        return this._formBuilder.group({
            street: ['', forms_1.Validators.required],
            postcode: ['', [forms_1.Validators.required]],
            phone: ['', [forms_1.Validators.required, forms_1.Validators.pattern(phoneNoRegex)]]
        });
    };
    FormComponent.prototype.userFormSave = function (model) {
        this.usersubmitted = true; // set form submit to true
        // call API to save customer
        console.log(model);
    };
    FormComponent.prototype.addAddress = function () {
        // add address to the list
        var control = this.myForm.controls['addresses'];
        control.push(this.initAddress());
    };
    FormComponent.prototype.removeAddress = function (i) {
        // remove address from the list
        var control = this.myForm.controls['addresses'];
        control.removeAt(i);
    };
    FormComponent.prototype.save = function (model, isValid) {
        this.submitted = true; // set form submit to true
        // check if model is valid
        // if valid, call API to save customer
        console.log(model, isValid);
    };
    FormComponent.prototype.saveUser = function (value, valid) {
        console.log(value, valid);
        console.log(this.user);
    };
    return FormComponent;
}());
FormComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        selector: 'my-app',
        templateUrl: 'form.html',
    }),
    __metadata("design:paramtypes", [forms_1.FormBuilder, router_1.Router])
], FormComponent);
exports.FormComponent = FormComponent;
//# sourceMappingURL=form.component.js.map