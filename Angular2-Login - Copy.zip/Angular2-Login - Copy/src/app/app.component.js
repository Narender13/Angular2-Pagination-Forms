"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var login_service_1 = require("./service/login.service");
var message_service_1 = require("./service/message.service");
var authGuard_guard_1 = require("./authGuard.guard");
var router_2 = require("@angular/router");
var AppComponent = (function () {
    function AppComponent(messageService, route, router, user, _uthguardGuard) {
        var _this = this;
        this.messageService = messageService;
        this.route = route;
        this.router = router;
        this.user = user;
        this._uthguardGuard = _uthguardGuard;
        this.loading = true;
        this.messageService.getMessage().subscribe(function (message) { _this.message = message; });
        router.events.subscribe(function (event) {
            _this.navigationInterceptor(event);
        });
    }
    AppComponent.prototype.navigationInterceptor = function (event) {
        var _this = this;
        if (event instanceof router_2.NavigationStart) {
            this.loading = true;
        }
        if (event instanceof router_2.NavigationEnd) {
            setTimeout(function () { return _this.loading = false; }, 1000);
        }
        // Set loading state to false in both of the below events to hide the spinner in case a request fails
        if (event instanceof router_2.NavigationCancel) {
            setTimeout(function () { return _this.loading = false; }, 1000);
        }
        if (event instanceof router_2.NavigationError) {
            setTimeout(function () { return _this.loading = false; }, 1000);
        }
    };
    AppComponent.prototype.logout = function () {
        this.messageService.sendMessage('false');
        this.router.navigate(['/login']);
    };
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.loading = false;
        this.messageService.getLoadingMessage().subscribe(function (loading) { _this.isbindingDone = loading; });
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        templateUrl: "app/app.component.html",
    }),
    __metadata("design:paramtypes", [message_service_1.MessageService,
        router_1.ActivatedRoute,
        router_2.Router, login_service_1.UserService, authGuard_guard_1.AuthguardGuard])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map