"use strict";
var profile_component_1 = require("./profile/profile.component");
var home_component_1 = require("./home/home.component");
var login_component_1 = require("./login/login.component");
var authGuard_guard_1 = require("./authGuard.guard");
var pagination_component_1 = require("./Pagination/pagination.component");
var form_component_1 = require("./form/form.component");
// import { LoginComponent } from './login/login.component';
exports.routes = [
    // { path: '', component: LoginComponent },
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'home', canActivate: [authGuard_guard_1.AuthguardGuard], component: home_component_1.HomeComponent },
    { path: 'profile', canActivate: [authGuard_guard_1.AuthguardGuard], component: profile_component_1.ProfileComponent },
    { path: 'pagination', canActivate: [authGuard_guard_1.AuthguardGuard], component: pagination_component_1.PaginationComponent },
    { path: 'form', canActivate: [authGuard_guard_1.AuthguardGuard], component: form_component_1.FormComponent },
    { path: '**', component: login_component_1.LoginComponent }
];
//# sourceMappingURL=app.routes.js.map