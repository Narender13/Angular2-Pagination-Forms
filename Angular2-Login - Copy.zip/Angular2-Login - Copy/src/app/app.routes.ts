import { Routes } from '@angular/router';

import { ProfileComponent } from './profile/profile.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AuthguardGuard } from './authGuard.guard';
import { PaginationComponent } from './Pagination/pagination.component';
import { FormComponent } from './form/form.component';

// import { LoginComponent } from './login/login.component';

export const routes: Routes = [
    // { path: '', component: LoginComponent },
    { path: '', redirectTo: '/login', pathMatch: 'full' },
    { path: 'home', canActivate: [AuthguardGuard], component: HomeComponent },
    { path: 'profile', canActivate: [AuthguardGuard], component: ProfileComponent },
    { path: 'pagination', canActivate: [AuthguardGuard], component: PaginationComponent },
    { path: 'form', canActivate: [AuthguardGuard], component: FormComponent },
    { path: '**', component: LoginComponent }

    // { path: 'logout', component: LoginComponent }
];
