import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../service/login.service'
@Component({
    selector: 'profile',
    templateUrl: `./profile.html`
})
export class ProfileComponent {
    public loginDetail: boolean;
    public games: [{ game: string, platform: string, release: string }];
    public searchString: string;
    public couter: number = 0;

    constructor(private route: Router, private _loginService: UserService) {
    };

    increaseCouter() {
        this.couter++;


    }
    ngOnInit() {

    }

}
